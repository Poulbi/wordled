#!/bin/sh

firefox --private-window 'https://wordlearchive.com/'
